import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import pg from 'pg';

const {Pool}=pg;
const app=express();
app.use(cors({origin:process.env.CORS_ORIGIN||'*'}));
app.use(express.json({limit:'256kb'}));
const pool=process.env.DATABASE_URL?new Pool({connectionString:process.env.DATABASE_URL,ssl:process.env.DATABASE_URL.includes('localhost')?false:{rejectUnauthorized:false}}):null;

const required=['JWT_SECRET','CREATOR_ID','CREATOR_PASSWORD'];
function auth(req,res,next){
  const h=req.headers.authorization||'';
  const token=h.startsWith('Bearer ')?h.slice(7):null;
  if(!token)return res.status(401).json({code:'AUTH_REQUIRED',message:'Authentication required'});
  try{req.user=jwt.verify(token,process.env.JWT_SECRET);next();}
  catch{res.status(401).json({code:'AUTH_REQUIRED',message:'Invalid or expired session'});}
}
app.get('/health',async(req,res)=>{
  let db='disabled';
  if(pool){try{await pool.query('select 1');db='ok';}catch{db='failed';}}
  res.json({status:'ok',service:'GIDEON',database:db,creatorId:process.env.CREATOR_ID});
});
app.post('/auth/login',(req,res)=>{
  const {creatorId,password}=req.body||{};
  if(creatorId!==process.env.CREATOR_ID||password!==process.env.CREATOR_PASSWORD)
    return res.status(401).json({code:'AUTH_REQUIRED',message:'Creator credentials rejected'});
  const token=jwt.sign({creatorId,name:process.env.CREATOR_NAME,role:'creator'},process.env.JWT_SECRET,{expiresIn:'7d'});
  res.json({token,creator:{name:process.env.CREATOR_NAME,creatorId:process.env.CREATOR_ID,role:'creator'}});
});
app.post('/ai/chat',auth,async(req,res)=>{
  const {message,history=[]}=req.body||{};
  if(!message)return res.status(400).json({code:'FAILED',message:'Message is required'});
  const base=process.env.OPENAI_BASE_URL, key=process.env.OPENAI_API_KEY, model=process.env.OPENAI_MODEL;
  if(!base||!key||!model)return res.status(503).json({code:'FAILED',message:'LLM backend is not configured'});
  const system=`You are GIDEON, a real-world Android AI assistant. Creator: ${process.env.CREATOR_NAME}, Creator ID: ${process.env.CREATOR_ID}. Never claim an Android action succeeded unless the client reports success.`;
  try{
    const r=await fetch(`${base.replace(/\/$/,'')}/chat/completions`,{
      method:'POST',headers:{'content-type':'application/json','authorization':`Bearer ${key}`},
      body:JSON.stringify({model,messages:[{role:'system',content:system},...history.slice(-12),{role:'user',content:message}],temperature:.3})
    });
    const body=await r.json();
    if(!r.ok) return res.status(502).json({code:'FAILED',message:body?.error?.message||'LLM provider failed'});
    const reply=body?.choices?.[0]?.message?.content;
    if(!reply) return res.status(502).json({code:'FAILED',message:'LLM returned no text'});
    res.json({reply});
  }catch(e){res.status(503).json({code:'OFFLINE',message:'AI service unavailable'});}
});
app.get('/memory',auth,async(req,res)=>{
  if(!pool)return res.status(503).json({code:'FAILED',message:'Database is not configured'});
  const r=await pool.query('select id,text,created_at from memories where creator_id=$1 order by created_at desc',[req.user.creatorId]);
  res.json({items:r.rows});
});
app.post('/memory',auth,async(req,res)=>{
  if(!pool)return res.status(503).json({code:'FAILED',message:'Database is not configured'});
  const text=String(req.body?.text||'').trim(); if(!text)return res.status(400).json({code:'FAILED',message:'Memory text required'});
  const id=crypto.randomUUID(); await pool.query('insert into memories(id,creator_id,text) values($1,$2,$3)',[id,req.user.creatorId,text]);
  res.status(201).json({id});
});
app.delete('/memory/:id',auth,async(req,res)=>{
  if(!pool)return res.status(503).json({code:'FAILED',message:'Database is not configured'});
  await pool.query('delete from memories where id=$1 and creator_id=$2',[req.params.id,req.user.creatorId]); res.status(204).end();
});
app.get('/time',(_,res)=>res.json({iso:new Date().toISOString()}));
app.get('/search',async(req,res)=>{
  const q=String(req.query.q||'').trim(); if(!q)return res.status(400).json({code:'FAILED',message:'q required'});
  const url=`https://www.google.com/search?q=${encodeURIComponent(q)}`;
  res.json({url});
});
for(const k of required)if(!process.env[k])console.warn(`Missing environment variable: ${k}`);
const port=Number(process.env.PORT||8080);
app.listen(port,()=>console.log(`GIDEON backend listening on ${port}`));
