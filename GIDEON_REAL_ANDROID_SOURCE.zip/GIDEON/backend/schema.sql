create table if not exists memories(
 id uuid primary key,
 creator_id text not null,
 text text not null,
 created_at timestamptz not null default now()
);
create index if not exists memories_creator_idx on memories(creator_id, created_at desc);
