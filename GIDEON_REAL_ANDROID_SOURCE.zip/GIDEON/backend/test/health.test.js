import test from 'node:test';
import assert from 'node:assert/strict';
test('environment contract',()=> {
  assert.ok(process.env.NODE_ENV === undefined || typeof process.env.NODE_ENV === 'string');
});
