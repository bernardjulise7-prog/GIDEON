# GIDEON — real Android AI assistant

GIDEON is built from the Hark/OACP architecture and renamed/extended for Joe (`SONLSEPYOK`). Hark provides a real foundation for Android assistant integration: Flutter UI, STT/TTS, system assistant integration, overlay architecture and OACP app capability discovery.

## Important
This repository is source-first. The included Flutter project and Node backend are intended to be built with Flutter/Android tooling. An APK is **not claimed as verified** until it is built and tested on a physical Android device.

## Architecture

- Flutter: chat, voice UI, state, backend client, local actions.
- Android/Kotlin: system assistant hooks and real Android intents.
- Backend: authentication, secure server-side LLM key, memory API, health endpoint.
- PostgreSQL: persistent user-approved memories.
- OACP-compatible extension point: `packages/hark_platform`.

## Creator

- Name: Joe
- Creator ID: SONLSEPYOK
- Creator authentication is password-based on the backend. The creator ID alone is never sufficient.

## Run backend

```bash
cd backend
cp .env.example .env
# set JWT_SECRET, CREATOR_PASSWORD, OPENAI_API_KEY and DATABASE_URL
npm install
psql "$DATABASE_URL" -f schema.sql
npm start
```

## Run Flutter

Install Flutter stable and Android SDK, then:

```bash
flutter pub get
flutter run --dart-define=GIDEON_BACKEND_URL=http://10.0.2.2:8080
```

For a physical phone, replace the backend URL with a reachable HTTPS URL.

## Security

- No LLM secret is stored in the APK.
- Backend secrets are environment variables.
- Creator authentication is server-side.
- Android permissions must be granted by the user.
- The app never reports an Android action as successful unless the Android call returns success.

## Current real capabilities

- Android microphone speech recognition through `speech_to_text`.
- Android TTS through `flutter_tts`.
- Backend health check.
- Server-side LLM call through an OpenAI-compatible API.
- Creator authentication.
- Persistent PostgreSQL memory CRUD.
- Real web URL opening.
- Real Android calendar/reminder intent.
- Real Android settings intent.
- Android system-assistant intent hooks.

## Deliberate limitations

A generic Android app cannot silently control arbitrary apps, read notifications, or perform accessibility actions without the relevant user-granted Android service/permission. Those features must be implemented as explicit permission-gated native services, not simulated.

Wake-word and always-on microphone behavior also depends on Android foreground-service rules, OEM battery restrictions, and the selected offline wake-word engine. The architecture leaves a native service entry point for that implementation rather than pretending a normal STT listener is a wake-word engine.

## Verification checklist

Before release:

1. `flutter analyze`
2. `flutter test`
3. `npm test` in backend
4. Build debug APK.
5. Install on physical device.
6. Grant microphone permission.
7. Test STT and TTS.
8. Test backend `/health`.
9. Test creator login.
10. Test one real LLM request.
11. Test memory create/list/delete.
12. Test Android settings and calendar intents.
13. Disable internet and verify OFFLINE MODE.
14. Test default-assistant role on a compatible Android version.
15. Only then build a signed release APK.

## Base architecture

Hark's open-source repository is the architectural reference used here:
https://github.com/OpenAppCapabilityProtocol/hark
