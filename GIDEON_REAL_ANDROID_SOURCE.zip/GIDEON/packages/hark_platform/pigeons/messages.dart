import 'package:pigeon/pigeon.dart';

@HostApi()
abstract class HarkMainApi {
  void openAssistantSettings();
}

@FlutterApi()
abstract class HarkResultFlutterApi {
  void onActionResult(String requestId, String status, String message);
}
