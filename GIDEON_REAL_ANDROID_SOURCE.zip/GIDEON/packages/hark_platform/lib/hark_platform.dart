import 'package:flutter/services.dart';
class HarkPlatform {
  static const MethodChannel _channel=MethodChannel('gideon/hark_platform');
  Future<void> openAssistantSettings() => _channel.invokeMethod('openAssistantSettings');
}
