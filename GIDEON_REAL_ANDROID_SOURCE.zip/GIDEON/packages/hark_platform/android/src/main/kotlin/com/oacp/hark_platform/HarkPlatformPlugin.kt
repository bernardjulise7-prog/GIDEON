package com.oacp.hark_platform
import android.content.Context
import io.flutter.embedding.engine.plugins.FlutterPlugin
import io.flutter.plugin.common.MethodChannel
class HarkPlatformPlugin: FlutterPlugin {
 private lateinit var channel: MethodChannel
 override fun onAttachedToEngine(binding: FlutterPlugin.FlutterPluginBinding) {
   channel=MethodChannel(binding.binaryMessenger,"gideon/hark_platform")
   channel.setMethodCallHandler { call,result ->
     if(call.method=="openAssistantSettings") {
       val i=android.content.Intent(android.provider.Settings.ACTION_VOICE_INPUT_SETTINGS)
       i.addFlags(android.content.Intent.FLAG_ACTIVITY_NEW_TASK)
       binding.applicationContext.startActivity(i); result.success(null)
     } else result.notImplemented()
   }
 }
 override fun onDetachedFromEngine(binding: FlutterPlugin.FlutterPluginBinding) { channel.setMethodCallHandler(null) }
}
