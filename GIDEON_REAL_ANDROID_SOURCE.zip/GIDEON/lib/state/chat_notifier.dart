import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'chat_state.dart';
import '../services/backend_service.dart';
import 'services_providers.dart';

class ChatNotifier extends Notifier<ChatState> {
  late final BackendService backend;
  @override ChatState build() { backend=ref.read(backendProvider); return const ChatState(); }

  Future<void> refreshHealth() async {
    final online = await backend.health();
    state=state.copyWith(online:online,mode:online?GideonMode.idle:GideonMode.offline);
  }

  Future<String?> send(String text) async {
    state=state.copyWith(messages:[...state.messages,ChatMessage(text,fromUser:true)],mode:GideonMode.processing);
    try {
      final reply=await backend.chat(text,state.messages.where((m)=>m.text!=text).map((m)=>{'role':m.fromUser?'user':'assistant','content':m.text}).toList());
      state=state.copyWith(messages:[...state.messages,ChatMessage(reply,fromUser:false)],mode:GideonMode.idle);
      return reply;
    } on BackendException catch(e) {
      state=state.copyWith(messages:[...state.messages,ChatMessage('[${e.code}] ${e.message}',fromUser:false)],mode:GideonMode.failed);
      return null;
    }
  }
}
final chatProvider=NotifierProvider<ChatNotifier,ChatState>(ChatNotifier.new);
