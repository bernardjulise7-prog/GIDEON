import 'package:flutter_riverpod/flutter_riverpod.dart';
class InitNotifier extends AsyncNotifier<void> {
  @override Future<void> build() async {}
}
final initProvider = AsyncNotifierProvider<InitNotifier,void>(InitNotifier.new);
