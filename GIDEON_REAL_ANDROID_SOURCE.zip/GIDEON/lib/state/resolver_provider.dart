import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/nlu_command_resolver.dart';
final resolverProvider = Provider((_) => NluCommandResolver());
