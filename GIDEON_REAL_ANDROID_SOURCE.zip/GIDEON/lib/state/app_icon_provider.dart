import 'package:flutter_riverpod/flutter_riverpod.dart';
final appIconProvider = Provider((_) => <String,String>{});
