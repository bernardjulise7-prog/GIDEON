class ChatMessage {
  final String text; final bool fromUser; final DateTime time;
  ChatMessage(this.text,{required this.fromUser,DateTime? time}):time=time??DateTime.now();
}
enum GideonMode { idle, listening, processing, speaking, offline, failed }
class ChatState {
  final List<ChatMessage> messages; final GideonMode mode; final bool online;
  const ChatState({this.messages=const [],this.mode=GideonMode.idle,this.online=false});
  ChatState copyWith({List<ChatMessage>? messages,GideonMode? mode,bool? online}) =>
    ChatState(messages:messages??this.messages,mode:mode??this.mode,online:online??this.online);
}
