import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/capability_registry.dart';
final registryProvider = Provider((_) => CapabilityRegistry());
