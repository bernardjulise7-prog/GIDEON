import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/stt_service.dart';
import '../services/tts_service.dart';
import '../services/auth_service.dart';
import '../services/intent_dispatcher.dart';
import '../services/backend_service.dart';

final sttProvider = Provider((_) => SttService());
final ttsProvider = Provider((_) => TtsService());
final authProvider = Provider((_) => AuthService());
final dispatcherProvider = Provider((_) => IntentDispatcher());
final backendProvider = Provider((_) => BackendService(const String.fromEnvironment(
  'GIDEON_BACKEND_URL', defaultValue:'http://10.0.2.2:8080',
)));
