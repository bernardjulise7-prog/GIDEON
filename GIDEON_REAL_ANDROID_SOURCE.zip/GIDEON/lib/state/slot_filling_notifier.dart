import 'package:flutter_riverpod/flutter_riverpod.dart';
class SlotFillingNotifier extends Notifier<bool> {
  @override bool build() => false;
}
final slotFillingProvider = NotifierProvider<SlotFillingNotifier,bool>(SlotFillingNotifier.new);
