import 'package:flutter_riverpod/flutter_riverpod.dart';
class EmbeddingNotifier extends Notifier<bool> {
  @override bool build() => false;
}
final embeddingProvider = NotifierProvider<EmbeddingNotifier,bool>(EmbeddingNotifier.new);
