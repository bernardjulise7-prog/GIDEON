import 'assistant_action.dart';
class ResolvedAction {
  final AssistantAction action;
  final Map<String,String> params;
  const ResolvedAction(this.action, this.params);
}
