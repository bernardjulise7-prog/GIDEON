enum ActionStatus { success, failed, offline, permissionRequired, authRequired }

class AssistantAction {
  final String id;
  final String label;
  final String description;
  final bool requiresPermission;
  const AssistantAction({
    required this.id, required this.label, required this.description,
    this.requiresPermission = false,
  });
}
