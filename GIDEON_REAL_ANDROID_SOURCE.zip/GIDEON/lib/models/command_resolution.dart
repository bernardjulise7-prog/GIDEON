import 'assistant_action.dart';
class CommandResolution {
  final AssistantAction? action;
  final Map<String,String> params;
  final ActionStatus status;
  final String message;
  const CommandResolution({
    this.action, this.params = const {}, required this.status, required this.message,
  });
}
