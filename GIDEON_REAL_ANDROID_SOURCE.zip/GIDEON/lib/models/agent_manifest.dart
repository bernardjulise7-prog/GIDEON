class AgentManifest {
  final String name;
  final String creator;
  final String creatorId;
  const AgentManifest({
    required this.name, required this.creator, required this.creatorId,
  });
  static const current = AgentManifest(
    name: 'GIDEON', creator: 'Joe', creatorId: 'SONLSEPYOK',
  );
}
