enum DiscoveredAppStatus { idle, scanning, ready, failed }
