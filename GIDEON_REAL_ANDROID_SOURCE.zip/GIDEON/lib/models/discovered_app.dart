class DiscoveredApp {
  final String packageName;
  final String label;
  final bool enabled;
  const DiscoveredApp({required this.packageName, required this.label, this.enabled=true});
}
