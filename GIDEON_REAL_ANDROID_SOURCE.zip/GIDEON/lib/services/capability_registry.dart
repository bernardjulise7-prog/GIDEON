import '../models/assistant_action.dart';
class CapabilityRegistry {
  List<AssistantAction> get actions => const [
    AssistantAction(id:'open_web',label:'Open website',description:'Open a website'),
    AssistantAction(id:'reminder',label:'Create reminder',description:'Create a reminder'),
    AssistantAction(id:'settings',label:'Open settings',description:'Open Android settings'),
    AssistantAction(id:'camera',label:'Use camera',description:'Use camera after permission',requiresPermission:true),
    AssistantAction(id:'share',label:'Share content',description:'Use Android share sheet'),
  ];
}
