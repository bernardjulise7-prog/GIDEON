import 'capability_registry.dart';
class CapabilityHelpService {
  final CapabilityRegistry registry;
  CapabilityHelpService(this.registry);
  String describe() => registry.actions.map((a)=>'• ${a.label}: ${a.description}').join('\n');
}
