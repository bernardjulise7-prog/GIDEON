import '../models/command_resolution.dart';
abstract class CommandResolver {
  Future<CommandResolution> resolve(String text);
}
