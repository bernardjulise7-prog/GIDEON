import 'package:speech_to_text/speech_to_text.dart';
import 'package:flutter/foundation.dart';

class SttService {
  final SpeechToText _stt = SpeechToText();
  bool _ready = false;
  bool get isListening => _stt.isListening;

  Future<bool> initialize() async {
    if (_ready) return true;
    _ready = await _stt.initialize(
      onError: (e) => debugPrint('STT: $e'),
      onStatus: (s) => debugPrint('STT status: $s'),
    );
    return _ready;
  }

  Future<void> listen({
    required void Function(String text, bool finalResult) onResult,
    required VoidCallback onDone,
  }) async {
    if (!await initialize()) return;
    await _stt.listen(
      partialResults: true,
      listenFor: const Duration(seconds: 30),
      pauseFor: const Duration(seconds: 4),
      onResult: (r) => onResult(r.recognizedWords, r.finalResult),
      onSoundLevelChange: (_) {},
    );
    Future.delayed(const Duration(seconds: 31), onDone);
  }

  Future<void> stop() => _stt.stop();
}
