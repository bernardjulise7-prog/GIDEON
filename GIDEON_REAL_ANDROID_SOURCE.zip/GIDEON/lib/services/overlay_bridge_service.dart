import 'package:flutter_riverpod/flutter_riverpod.dart';
class OverlayBridgeService {}
final overlayBridgeProvider = Provider((_) => OverlayBridgeService());
