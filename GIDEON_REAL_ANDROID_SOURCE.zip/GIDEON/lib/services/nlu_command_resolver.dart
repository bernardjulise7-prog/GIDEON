import '../models/assistant_action.dart';
import '../models/command_resolution.dart';
import 'command_resolver.dart';

class NluCommandResolver implements CommandResolver {
  @override
  Future<CommandResolution> resolve(String text) async {
    final t = text.toLowerCase();
    if (t.contains('open') && (t.contains('http') || t.contains('website') || t.contains('google'))) {
      return CommandResolution(
        action: const AssistantAction(id:'open_web',label:'Open website',description:'Open a web address'),
        params: {'url': t.contains('google') ? 'https://www.google.com' : 'https://www.google.com'},
        status: ActionStatus.success, message:'Resolved web action');
    }
    if (t.contains('remind') || t.contains('reminder')) {
      return const CommandResolution(
        action: AssistantAction(id:'reminder',label:'Create reminder',description:'Create an Android reminder'),
        status: ActionStatus.success, message:'Resolved reminder action');
    }
    if (t.contains('settings')) {
      return const CommandResolution(
        action: AssistantAction(id:'settings',label:'Open settings',description:'Open Android settings'),
        status: ActionStatus.success, message:'Resolved settings action');
    }
    return const CommandResolution(status:ActionStatus.success,message:'No local action matched');
  }
}
