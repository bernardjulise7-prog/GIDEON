import 'package:flutter/services.dart';
import 'package:url_launcher/url_launcher.dart';

enum DispatchStatus { success, failed, permissionRequired }

class IntentDispatcher {
  static const _channel = MethodChannel('gideon/android_actions');

  Future<DispatchStatus> openUrl(String url) async {
    try {
      final ok = await launchUrl(Uri.parse(url), mode: LaunchMode.externalApplication);
      return ok ? DispatchStatus.success : DispatchStatus.failed;
    } catch (_) { return DispatchStatus.failed; }
  }

  Future<DispatchStatus> createReminder(String title, DateTime when) async {
    try {
      final ok = await _channel.invokeMethod<bool>('createReminder', {
        'title': title, 'timeMillis': when.millisecondsSinceEpoch,
      });
      return ok == true ? DispatchStatus.success : DispatchStatus.failed;
    } catch (_) { return DispatchStatus.failed; }
  }

  Future<DispatchStatus> openSettings(String section) async {
    try {
      final ok = await _channel.invokeMethod<bool>('openSettings', {'section':section});
      return ok == true ? DispatchStatus.success : DispatchStatus.failed;
    } catch (_) { return DispatchStatus.failed; }
  }
}
