import 'dart:convert';
import 'dart:io';
import 'package:path_provider/path_provider.dart';
class InferenceLogger {
  Future<void> log(Map<String,dynamic> event) async {
    final dir = await getApplicationDocumentsDirectory();
    final f = File('${dir.path}/gideon.jsonl');
    await f.writeAsString('${jsonEncode(event)}\n', mode:FileMode.append);
  }
}
