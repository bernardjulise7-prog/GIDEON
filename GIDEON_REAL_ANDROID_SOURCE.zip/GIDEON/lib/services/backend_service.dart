import 'dart:convert';
import 'package:http/http.dart' as http;

class BackendException implements Exception {
  final String message;
  final String code;
  BackendException(this.message, this.code);
  @override String toString() => '$code: $message';
}

class BackendService {
  final String baseUrl;
  final http.Client client;
  String? token;
  BackendService(this.baseUrl, {http.Client? client}) : client = client ?? http.Client();

  Future<bool> health() async {
    try {
      final r = await client.get(Uri.parse('$baseUrl/health')).timeout(const Duration(seconds: 6));
      return r.statusCode == 200 && jsonDecode(r.body)['status'] == 'ok';
    } catch (_) { return false; }
  }

  Future<Map<String,dynamic>> login(String creatorId, String password) async {
    final r = await client.post(Uri.parse('$baseUrl/auth/login'),
      headers: {'content-type':'application/json'},
      body: jsonEncode({'creatorId':creatorId,'password':password}),
    ).timeout(const Duration(seconds: 10));
    final body = jsonDecode(r.body);
    if (r.statusCode != 200) throw BackendException(body['message'] ?? 'Authentication failed','AUTH_REQUIRED');
    token = body['token'];
    return body;
  }

  Future<String> chat(String message, List<Map<String,String>> history) async {
    if (token == null) throw BackendException('Login required','AUTH_REQUIRED');
    final r = await client.post(Uri.parse('$baseUrl/ai/chat'),
      headers: {'content-type':'application/json','authorization':'Bearer $token'},
      body: jsonEncode({'message':message,'history':history}),
    ).timeout(const Duration(seconds: 30));
    final body = jsonDecode(r.body);
    if (r.statusCode != 200) throw BackendException(body['message'] ?? 'AI request failed', body['code'] ?? 'FAILED');
    return body['reply'] as String;
  }

  Future<List<Map<String,dynamic>>> memories() async {
    if (token == null) throw BackendException('Login required','AUTH_REQUIRED');
    final r = await client.get(Uri.parse('$baseUrl/memory'),
      headers: {'authorization':'Bearer $token'});
    if (r.statusCode != 200) throw BackendException('Memory request failed','FAILED');
    return List<Map<String,dynamic>>.from(jsonDecode(r.body)['items']);
  }

  Future<void> addMemory(String text) async {
    final r = await client.post(Uri.parse('$baseUrl/memory'),
      headers: {'content-type':'application/json','authorization':'Bearer $token'},
      body: jsonEncode({'text':text}));
    if (r.statusCode != 201) throw BackendException('Could not save memory','FAILED');
  }

  Future<void> deleteMemory(String id) async {
    final r = await client.delete(Uri.parse('$baseUrl/memory/$id'),
      headers: {'authorization':'Bearer $token'});
    if (r.statusCode != 204) throw BackendException('Could not delete memory','FAILED');
  }
}
