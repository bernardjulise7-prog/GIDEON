import 'package:flutter_secure_storage/flutter_secure_storage.dart';

class AuthService {
  final FlutterSecureStorage storage = const FlutterSecureStorage();
  Future<void> saveToken(String token) => storage.write(key:'gideon_token',value:token);
  Future<String?> readToken() => storage.read(key:'gideon_token');
  Future<void> clear() => storage.delete(key:'gideon_token');
}
