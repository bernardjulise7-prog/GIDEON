import '../models/command_resolution.dart';
import 'command_resolver.dart';
import 'inference_logger.dart';
class LoggingCommandResolver implements CommandResolver {
  final CommandResolver inner; final InferenceLogger logger;
  LoggingCommandResolver(this.inner,this.logger);
  @override Future<CommandResolution> resolve(String text) async {
    final r = await inner.resolve(text);
    await logger.log({'input':text,'status':r.status.name,'action':r.action?.id});
    return r;
  }
}
