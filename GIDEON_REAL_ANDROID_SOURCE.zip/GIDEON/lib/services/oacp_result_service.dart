class OacpResultService {
  void register() {}
}
