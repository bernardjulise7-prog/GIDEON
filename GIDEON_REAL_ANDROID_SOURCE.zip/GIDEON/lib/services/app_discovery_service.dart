import '../models/discovered_app.dart';
class AppDiscoveryService {
  Future<List<DiscoveredApp>> discover() async => const [
    DiscoveredApp(packageName:'android',label:'Android system'),
  ];
}
