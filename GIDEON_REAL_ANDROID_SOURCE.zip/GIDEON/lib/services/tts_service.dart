import 'package:flutter_tts/flutter_tts.dart';

class TtsService {
  final FlutterTts _tts = FlutterTts();
  bool ready = false;
  Future<void> initialize() async {
    if (ready) return;
    await _tts.awaitSpeakCompletion(true);
    await _tts.setLanguage('en-US');
    await _tts.setSpeechRate(0.48);
    await _tts.setVolume(1.0);
    ready = true;
  }
  Future<void> speak(String text) async { await initialize(); await _tts.speak(text); }
  Future<void> stop() => _tts.stop();
}
