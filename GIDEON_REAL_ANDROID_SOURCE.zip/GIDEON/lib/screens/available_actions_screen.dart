import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../state/registry_provider.dart';
class AvailableActionsScreen extends ConsumerWidget {
  const AvailableActionsScreen({super.key});
  @override Widget build(BuildContext context,WidgetRef ref)=>Scaffold(
    appBar:AppBar(title:const Text('Available capabilities')),
    body:ListView(children:ref.watch(registryProvider).actions.map((a)=>ListTile(
      leading:const Icon(Icons.bolt),title:Text(a.label),subtitle:Text(a.description),
      trailing:a.requiresPermission?const Icon(Icons.lock_outline):null,
    )).toList()),
  );
}
