import 'package:flutter/material.dart';
class OverlayScreen extends StatelessWidget { const OverlayScreen({super.key});
  @override Widget build(BuildContext context)=>Material(child:Container(
    padding:const EdgeInsets.all(18),decoration:BoxDecoration(color:Colors.black.withOpacity(.94),borderRadius:BorderRadius.circular(24)),
    child:const Column(mainAxisSize:MainAxisSize.min,children:[Text('GIDEON',style:TextStyle(fontSize:24,fontWeight:FontWeight.bold)),SizedBox(height:8),Text('Assistant overlay ready.')]))); }
}
