import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../models/agent_manifest.dart';
import '../state/chat_notifier.dart';
import '../state/chat_state.dart';
import '../state/services_providers.dart';
import '../services/auth_service.dart';
import 'available_actions_screen.dart';

class ChatScreen extends ConsumerStatefulWidget { const ChatScreen({super.key}); @override ConsumerState<ChatScreen> createState()=>_ChatState(); }
class _ChatState extends ConsumerState<ChatScreen> {
  final input=TextEditingController();
  bool authenticated=false;
  @override void initState(){super.initState(); WidgetsBinding.instance.addPostFrameCallback((_){ref.read(chatProvider.notifier).refreshHealth();});}
  Future<void> login() async {
    final id=TextEditingController(text:AgentManifest.current.creatorId);
    final pass=TextEditingController();
    final ok=await showDialog<bool>(context:context,builder:(_)=>AlertDialog(
      title:const Text('Creator authentication'),
      content:Column(mainAxisSize:MainAxisSize.min,children:[
        TextField(controller:id,decoration:const InputDecoration(labelText:'Creator ID')),
        TextField(controller:pass,obscureText:true,decoration:const InputDecoration(labelText:'Password')),
      ]),
      actions:[TextButton(onPressed:()=>Navigator.pop(context,false),child:const Text('Cancel')),
        FilledButton(onPressed:()=>Navigator.pop(context,true),child:const Text('Authenticate'))],
    ));
    if(ok!=true)return;
    try {
      final b=ref.read(backendProvider); final body=await b.login(id.text.trim(),pass.text);
      await ref.read(authProvider).saveToken(body['token']);
      setState(()=>authenticated=true);
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Welcome back, Joe. Creator identity SONLSEPYOK verified. GIDEON is online.')));
    } catch(e) {
      if(mounted)ScaffoldMessenger.of(context).showSnackBar(SnackBar(content:Text('$e')));
    }
  }
  Future<void> voice() async {
    final stt=ref.read(sttProvider); final tts=ref.read(ttsProvider);
    await stt.listen(onResult:(text,finalResult){input.text=text;if(finalResult) {setState((){});}},onDone:(){});
    setState((){});
  }
  Future<void> send() async {
    final text=input.text.trim(); if(text.isEmpty)return; input.clear();
    final reply=await ref.read(chatProvider.notifier).send(text);
    if(reply!=null) await ref.read(ttsProvider).speak(reply);
  }
  @override Widget build(BuildContext context){
    final s=ref.watch(chatProvider);
    final color=s.mode==GideonMode.listening?Colors.redAccent:Colors.cyanAccent;
    return Scaffold(
      appBar:AppBar(title:const Text('GIDEON'),actions:[
        IconButton(onPressed:()=>Navigator.push(context,MaterialPageRoute(builder:(_)=>const AvailableActionsScreen())),icon:const Icon(Icons.bolt)),
        IconButton(onPressed:login,icon:Icon(authenticated?Icons.verified_user:Icons.lock_outline)),
      ]),
      body:Column(children:[
        Padding(padding:const EdgeInsets.all(12),child:Row(children:[
          Container(width:12,height:12,decoration:BoxDecoration(shape:BoxShape.circle,color:s.online?Colors.green:Colors.orange)),
          const SizedBox(width:8),Text(s.online?'ONLINE':'OFFLINE MODE'),
          const Spacer(),Text(s.mode.name.toUpperCase(),style:TextStyle(color:color,fontWeight:FontWeight.bold))
        ])),
        Expanded(child:ListView.builder(itemCount:s.messages.length,itemBuilder:(c,i){
          final m=s.messages[i]; return Align(alignment:m.fromUser?Alignment.centerRight:Alignment.centerLeft,
            child:Container(margin:const EdgeInsets.symmetric(horizontal:12,vertical:5),padding:const EdgeInsets.all(12),
              decoration:BoxDecoration(borderRadius:BorderRadius.circular(16),color:m.fromUser?Colors.blueGrey.shade800:Colors.black),
              child:Text(m.text)));
        })),
        Container(padding:const EdgeInsets.all(10),child:Row(children:[
          IconButton(onPressed:voice,icon:Icon(Icons.mic,color:color)),
          Expanded(child:TextField(controller:input,onSubmitted:(_)=>send(),decoration:const InputDecoration(hintText:'Talk to GIDEON...',border:OutlineInputBorder()))),
          IconButton(onPressed:send,icon:const Icon(Icons.send))
        ]))
      ]),
    );
  }
}
