import 'package:flutter/material.dart';
import 'chat_screen.dart';
class SplashScreen extends StatefulWidget { const SplashScreen({super.key}); @override State<SplashScreen> createState()=>_SplashState(); }
class _SplashState extends State<SplashScreen> {
  @override void initState(){super.initState(); Future.delayed(const Duration(milliseconds:700),()=>mounted?Navigator.pushReplacement(context,MaterialPageRoute(builder:(_)=>const ChatScreen())):null);}
  @override Widget build(BuildContext context)=>const Scaffold(body:Center(child:Text('GIDEON',style:TextStyle(fontSize:42,fontWeight:FontWeight.w800,letterSpacing:8))));
}
