package com.oacp.hark
import android.speech.RecognitionService
class HarkRecognitionService: RecognitionService() {
 override fun onStartListening(intent:android.content.Intent,listener:android.speech.RecognitionListener) { listener.onError(android.speech.SpeechRecognizer.ERROR_RECOGNIZER_BUSY) }
 override fun onCancel(listener:android.speech.RecognitionListener) {}
 override fun onStopListening(listener:android.speech.RecognitionListener) {}
}
