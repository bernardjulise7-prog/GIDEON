package com.oacp.hark
import android.service.voice.VoiceInteractionSession
class HarkSession(service: android.service.voice.VoiceInteractionService): VoiceInteractionSession(service)
