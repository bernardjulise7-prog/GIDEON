package com.oacp.hark
import android.app.*
import android.content.*
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel

class MainActivity: FlutterActivity() {
  private val channel="gideon/android_actions"
  override fun configureFlutterEngine(engine: FlutterEngine) {
    super.configureFlutterEngine(engine)
    MethodChannel(engine.dartExecutor.binaryMessenger,channel).setMethodCallHandler { call,result ->
      try {
        when(call.method) {
          "openSettings" -> {
            startActivity(Intent(Settings.ACTION_SETTINGS)); result.success(true)
          }
          "createReminder" -> {
            val title=call.argument<String>("title") ?: "GIDEON reminder"
            val millis=call.argument<Long>("timeMillis") ?: System.currentTimeMillis()
            val intent=Intent(Intent.ACTION_INSERT).apply {
              data=Uri.parse("content://com.android.calendar/events")
              putExtra("title",title); putExtra("beginTime",millis); putExtra("endTime",millis+60*60*1000)
            }
            startActivity(intent); result.success(true)
          }
          else -> result.notImplemented()
        }
      } catch(e: Exception) { result.success(false) }
    }
  }
}
