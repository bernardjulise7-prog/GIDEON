package com.oacp.hark
import android.service.voice.VoiceInteractionSessionService
import android.service.voice.VoiceInteractionSession
class HarkSessionService: VoiceInteractionSessionService() {
 override fun onNewSession(args: android.os.Bundle?): VoiceInteractionSession = HarkSession(this)
}
