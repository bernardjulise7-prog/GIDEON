package com.oacp.hark
import android.service.voice.VoiceInteractionService
class HarkVoiceInteractionService: VoiceInteractionService()
